说明：
	1. 按delete键可删除组件
	2. 按ctrl键可选择多个td

依赖组件
	0.jquery 1.9
	1.datepicker 日期选择
	2.colorpicker 颜色选择
	3.codebeautify html代码格式化
	4.main.js 部分初始化功能代码