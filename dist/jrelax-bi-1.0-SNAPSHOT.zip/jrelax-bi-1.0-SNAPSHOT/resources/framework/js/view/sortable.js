ns.ready(function(){
	ns.alert("此组件尚未实现具体功能！");
});